

class Main{
	
	public static ThreadQueue tq1 = new ThreadQueue(1000);
	public static inputBuffer buff = new inputBuffer(1000);
	public static void print(){
		for(int i=0;i<Main.tq1.getEnd();i++){
				System.out.println(Main.tq1.dequeue().getAmt());
			}			
	}
	public static void main(String args[]){
		Thread t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
		FCFS sch1=new FCFS();
		MyProducer p1=new MyProducer(1);
		MyProducer p2 = new MyProducer(2);
		MyProducer p3=new MyProducer(3);
		MyProducer p4 =new MyProducer(4);
		MyConsumer c1=new MyConsumer(1);
		MyConsumer c2=new MyConsumer(2);
		MyConsumer c3= new MyConsumer(3);
		t1=new Thread(p1);
		t2=new Thread(c1);
		t4=new Thread(p2);
		t5=new Thread(p3);
		t6=new Thread(p4);
		t7=new Thread(c2);
		t8=new Thread(c3);
		
		t3=new Thread(sch1);
		//t3.setDaemon(true);
		//t3.start();
		System.out.println("starting producer");
		t1.start();
		t4.start();
		t5.start();
		t6.start();
		System.out.println("starting consumer");
		t2.start();
		t7.start();
		t8.start();
		
		for(int i=0;i<1000;i++);	
		System.out.println("starting FCFS");
		t3.start();
		
		
		//System.out.println("Hiii");
		//Main.tq1=p1.getQBack();
		//tq1.printQueue();
		/*or(int i=0;i<Main.tq1.getEnd();i++){
			System.out.println(Main.tq1.dequeue().getAmt());
		}*/
		 try{  

 		 t2.join();  
 		}catch(Exception e){System.out.println(e);} 
		//t1.join();
		//demo d1= new demo();
		//Main.print();
		//for(int i=0;i<100;i++);
		//FCFS.schedule();

 		
	}
}
