//buffer ma bdha restictions and lag add krvanu che

import java.util.Date;
import java.lang.String;
import java.io.*;
import java.text.SimpleDateFormat;

class inputBuffer{
	private int buffer;
	private int size;
	private int point;
	private int flag_full;
	private int flag_empty;
	private File outFile;
	private FileWriter fWriter;
	public PrintWriter pWriter;
	public		Date date;
	private long tid=0;
	/***************
	File outFile = new File ("inputBuffer.dat");
	FileWriter fWriter=null;
 	try{  

     fWriter= new FileWriter (outFile);
    	
		 
 	}catch(IOException e){System.out.println("Cannot open file!!");} 
 	PrintWriter pWriter = new PrintWriter (fWriter);



	**********/
	inputBuffer(int n){
		this.buffer=0;
		this.size=n;
		this.point = this.buffer;
		this.flag_empty=1;
		this.flag_full=0;

	}
	protected void finalize(){
		pWriter.close();
	}



	private boolean isEmpty(){
		if(this.flag_empty==1)
			return true;
		else
			return false;
	}
	private boolean isFull(){
		if(this.flag_full==1)
			return true;
		else return false;

	}
	private boolean checkFull(){
		if(this.buffer>=size)
			return true;
		else return false;
	}
	private boolean checkEmpty(){
		if(this.buffer<=0)
			return true;
		else return false;

	}
	private boolean set_FlagFull(int flag){
		if(this.flag_full!=flag){
			this.flag_full=flag;
			return true;
		}
		else return false;

	}
	private boolean set_FlagEmpty(int flag){
		if(this.flag_empty!=flag){
			this.flag_empty=flag;
			return true;
		}
		else return false;
	}

	private boolean addToBuffer(int num,String nm){
		boolean dummy=false;
		if(isEmpty()){
			this.buffer=this.buffer+num;
			this.pWriter.println(tid+" "+nm+" adding to buffer: "+num+ " Status:"+this.buffer+" "+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(date));

			set_FlagEmpty(0);
			dummy=true;
		}
		else if(isFull()){

			dummy=false;
		}
		else{
			this.buffer=this.buffer+num;
			this.pWriter.println(tid+" "+nm+" adding to buffer: "+num+ " Status:"+this.buffer+" "+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(date));
			if(checkFull()){
				//rollback
				this.pWriter.println("Cannot add: "+num+" buffer size exceeds; Rolling back");
				this.buffer=this.buffer-num;
				dummy=false;
				if(this.buffer==size){
					this.pWriter.println("Buffer full");
					set_FlagFull(1);
					dummy=false;
				}
				//set_FlagFull(1);
			}
			else if(checkEmpty()){
				set_FlagEmpty(1);
				dummy=true;
			}
		}
		return dummy;

	}


	private boolean subFromBuffer(int num,String nm){
		boolean dummy=false;
		if(isFull()){
			//this.buffer=this.buffer-num;
			this.buffer=0;
			this.pWriter.println(tid+" "+nm+" eating to buffer;  Status:"+this.buffer+ " "+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(date));
			set_FlagFull(0);
			dummy=true;
		}
		else if(isEmpty()){

			dummy=false;
		}
		else{
			//this.buffer=this.buffer-num;
			this.buffer=0;
			this.pWriter.println(tid+" "+nm+" eating to buffer; Status:"+this.buffer+" "+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(date));
			if(checkFull()){
				set_FlagFull(1);
			}
			else if(checkEmpty()){
				this.pWriter.println("Cannot eat;Buffer Empty");
				this.buffer=this.buffer+num;
				dummy=false;
					if(this.buffer==0){
					this.pWriter.println("Buffer Empty");
					set_FlagEmpty(1);
					dummy=false;
					}

				
			}
		}
		return dummy;

	}

	//PUBLIC METHODS

	public synchronized boolean add(int num,String nm){

		return addToBuffer(num,nm);
	}

	public synchronized boolean eat(int num,String nm){
		return subFromBuffer(num,nm);
	}
	int i=1;
	public synchronized boolean Myrun(String name,int amt,long tidd){
		date=new Date();
		tid=tidd;
		//tid=Thread.currentThread().getId();
		/*System.out.println(i+" "+name);
		i++;*/
		this.pWriter=fopen();
		boolean dummy=false;
		if(name.startsWith("Producer")){
			dummy=add(amt,name);
		}
		else if(name.startsWith("Consumer")){
			dummy=eat(amt,name);
		}
		fclose();
		return dummy;

	}
	public void run(){
		System.out.println("hi input buffer");

	}

	public PrintWriter fopen(){
			this.outFile = new File ("inputBuffer.dat");
		try{  
     	this.fWriter= new FileWriter (outFile,true);  	
		 
 		}catch(IOException e){System.out.println("Cannot open file!!");} 
 		this.pWriter = new PrintWriter (fWriter);
 		return pWriter;
	}
	public void fclose(){
		this.finalize();
	}

	/*public static void main(String args[]){
		inputBuffer buff = new inputBuffer(500);
		buff.add(100);
		buff.eat(50);
		buff.add(230);

		buff.eat(60);
		buff.finalize();
	}*/

}
