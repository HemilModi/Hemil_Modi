import java.util.Random;

class MyConsumer implements Runnable{
	//final ThreadQueue  queue;
	MyThreads con;
	int num;
	int id=0;

	MyConsumer(ThreadQueue tq1){
		//this.queue=tq1;
		num=0;
	}
	MyConsumer(int i){this.id=i;}
	public void run(){
		//System.out.println("in Consumer");
		int i=0;
		while(i<10){
			//System.out.println("in consumer running");
			con=new MyThreads();
			//num=(new Random()).nextInt(50);
			num=1;
			con.makeNewThread(num,Main.buff,Main.tq1,"Consumer"+this.id);
			//System.out.println("consumer"+this.id+" "+num);
//			con.makeNewThread((new Random()).nextInt(50),Main.tq1,"Consumer");
			try{
			Thread.sleep(10);			
			}catch(Exception e){System.out.println("Sleep interrupted");}
			i++;
		}
	}
}	
