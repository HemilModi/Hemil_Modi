
import java.util.Date;
import java.lang.String;
import java.io.*;
import java.text.SimpleDateFormat;

class ThreadQueue implements Runnable {
	
	private MyThreads[] queue = null;
	private int head;
	private int tail;
	private File outFile;
	private FileWriter fWriter;
	public PrintWriter pWriter;
	public		Date date;
	
	MyThreads dumb=null;
	
	
	

	ThreadQueue(int n){
		queue=new MyThreads[n];
		head=0;
		tail=0;
		
		dumb=new MyThreads();
	}
	
	protected void finalize(){
		pWriter.close();
	}
	
	
	

	public synchronized void queuee(MyThreads m1){
		
		this.queue[this.tail]=m1;
		this.dumb=m1;
		//(new Thread(this)).start();
		this.tail++;
		
		
	}
	
	
	
	public synchronized void run()
	{
		this.pWriter=fopen();
		date=new Date();
	
		this.pWriter.println(this.queue[this.tail-1].tidd+" "+this.queue[this.tail-1].getsName()+": "+this.queue[this.tail-1].getAmt()+": "+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(this.queue[this.tail-1].date));
		fclose();	
	}
	public synchronized MyThreads dequeue(){
		MyThreads dummy= this.queue[head];
	
		
		//queue[queue.length-1]=null;
		return dummy;
	}

	public synchronized void dequeueSuccessful(){
			for(int i=0;i<this.tail;i++){
			queue[i]=queue[i+1];
			}
		this.tail=this.tail-1;
	}
	public int getEnd(){
		return this.tail;
	}

	public void printQueue(){
		for(int i=0;i<this.getEnd();i++){
			System.out.println(this.dequeue().getAmt());
		}		
	}
	
	public PrintWriter fopen(){
			this.outFile = new File ("ThreadQueue.dat");
		try{  
     	this.fWriter= new FileWriter (outFile,true);  	
		 
 		}catch(IOException e){System.out.println("Cannot open file!!");} 
 		this.pWriter = new PrintWriter (fWriter);
 		return pWriter;
	}
	public void fclose(){
		this.finalize();
	}
	
	/*public static void main(String args[]){
		ThreadQueue q1=new ThreadQueue(15);
		MyThreads m1 ;
		for(int i=0;i<10;i++){
			m1 = new MyThreads();
			m1.makeNewThread(i,null,q1);
			//q1.queuee(m1);

		}
		for(int i=0;i<q1.getEnd();i++){
			System.out.println(q1.dequeue().getAmt());
		}
	}*/
	
}
