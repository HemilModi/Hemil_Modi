import java.lang.*;
import java.util.Date;
import java.lang.String;
import java.io.*;
import java.text.SimpleDateFormat;

/*
brabr chale except that this.dummy.start call krvu padse  nd that this.start nhi chale
@issue: amt kai rite pass thase 
*/
 class Write implements Runnable{
        MyThreads m1=null;
        
	private File outFile;
	private FileWriter fWriter;
	public PrintWriter pWriter;
	public	Date date;
        
        Write(){
        //m1=new MyThreads();
        }
        
	protected void finalize(){
		pWriter.close();
	}

	public PrintWriter fopen(){
			this.outFile = new File ("MyThread.dat");
		try{  
     	this.fWriter= new FileWriter (outFile,true);  	
		 
 		}catch(IOException e){System.out.println("Cannot open file!!");} 
 		this.pWriter = new PrintWriter (fWriter);
 		return pWriter;
	}
	public void fclose(){
		this.finalize();
	}
        
        public synchronized void set(MyThreads m2)
        {
                this.m1=m2;
                (new Thread(this)).start();
        }
        public synchronized void run()
        {
		this.pWriter=fopen();
		this.date=new Date();
	
		this.pWriter.println(m1.tidd+" "+m1.getsName()+": "+m1.getAmt()+": "+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(m1.date));
		fclose();	
                
        }
        
        
 
 }

class MyThreads extends Thread{
	
	private int amount;
	private Thread dummy;
	private boolean ack;
	private String sname;
	//private Runnable target;
	private inputBuffer inbuff;
	private Write write=null;
        public long tidd=0;
        public Date date=null;
	MyThreads(){
		this.amount=0;
		this.dummy=null;
		this.ack=false;
		this.inbuff=null;
		//this.name=null;
		//this.target=null;
		this.write=new Write();
	}

	/*private Runnable getRunnable(){
		return this.target;
	}*/

	private boolean generateThread(String n1){
			//this.target=t;
			this.sname=n1;
			this.date=new Date();
			this.dummy=new Thread();
			this.tidd=dummy.getId();
			return true;
	}
			
	private boolean setAmount(int amt){
		this.amount=amt;
		return true;
	}

	private int getAmount(){
		return this.amount;
	}

	private long getDummyId(){
		return this.dummy.getId();
	}
	
	//public methods

	public synchronized void makeNewThread(int amt,inputBuffer b1,ThreadQueue q1,String n1){
			setAmount(amt);
			this.ack=generateThread(n1);
			write.set(this);
			q1.queuee(this);
			this.inbuff=b1;
			//this.name=n1;
			//return this;
	}
	/*
	public boolean makeNewThread(int amt,Runnable target,Scheduler1 sch1){
			setAmount(amt);
			this.ack=generateThread(target);
			sch1.addToArray(this);
			//this.MyThreadStart();
			return true;
	}*/
	public long getMyThreadId(){

		return this.getDummyId();
	}

	public synchronized boolean MyThreadStart(){
		//this.getRunnable().rund(this.amount);
		//System.out.println("starting MyThread");
		  return this.inbuff.Myrun(this.getsName(),this.getAmt(),this.tidd);
		//return true;
		//this.dummy.start();
	}

	public void MyThreadSuspend(){
		this.dummy.suspend();
	}

	public void MyThreadResume(){
		this.dummy.resume();
	}
	public void MyThreadDelay(){
		try{
               this.dummy.sleep(1000);
           }catch(InterruptedException e){ System.out.println("delay interrupted");}		
	}
	public int getAmt(){
		return this.getAmount();
	}

	public String getsName(){
		return this.sname;
	}
	}

	

	//CHECK CHECK MAIN CHECK!!! :p

	/*public static void main(String args[]){
		MyThreads mah1 = new MyThreads();
		st1 var=new st1();
		st2 var2=new st2();
		Scheduler1 sch=new Scheduler1(20);
		mah1.makeNewThread(23,var,sch);
		mah1.makeNewThread(44,var2,sch);
		System.out.println(mah1.getMyThreadId());
		//mah1.MyThreadStart();
	}*/




/*
	public void run(){
		int i=0;
		while(i<100){
		System.out.println("st1!!");
		i++;
		}
	}
}

class st2 implements Runnable{
	public void run(){
		int i=0;
		while(i<200){
		System.out.println("st2+++++++!!");
		i++;
		}
	}	
}*/
