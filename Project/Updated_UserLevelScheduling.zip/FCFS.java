import java.io.*;
import java.util.Date;

import java.text.SimpleDateFormat;

class FCFS implements Runnable{
		MyThreads handle=new MyThreads();
		Date date;
		ThreadQueue waiting = new ThreadQueue(100);
		boolean wait,just_add;


	public void run()
	{
		File outFile = new File ("FCFS.dat");
		FileWriter fWriter=null;
		PrintWriter pWriter=null;
 		wait=false;
 		just_add=true;
		boolean ret_type=false;
		int cnt=0;
		Main.tq1.printQueue();
		while(true)
		{
			date=new Date();

			if(this.waiting.getEnd()==0){
				wait=false;
			}

			if(Main.tq1.getEnd()!=0)
			{
				/*File opening*/
				try{  
		     	 fWriter= new FileWriter (outFile,true);			 
		 		}catch(IOException e){System.out.println("Cannot open file!!");} 
		 		pWriter = new PrintWriter (fWriter);
		 		System.out.println(wait);

		 		/**/
		 		if(wait & !just_add)
		 		{
		 			try{
		 			handle=this.waiting.dequeue();

		 			System.out.println(handle.getsName()+" "+ handle.getAmt());
					if(handle.MyThreadStart())
					{
						System.out.println("Local Done successfully");
						pWriter.println(handle.tidd+" "+handle.getsName()+" "+ handle.getAmt()+" "+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(handle.date)+" gets dispatched @"+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(date) );

						//File closing
						this.waiting.dequeueSuccessful(); 
					}	
					}catch(ArrayIndexOutOfBoundsException e){System.out.println("Cannot dequeue wait!!");wait=false;} 			
		 		}
				
						/**/

					try{	
					handle=Main.tq1.dequeue();				

					pWriter.println(handle.tidd+" "+handle.getsName()+" "+ handle.getAmt()+" "+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(handle.date)+" gets dispatched @"+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(date));
					
					if(handle.MyThreadStart()){
						System.out.println("Done successfully");
						//File closing
						Main.tq1.dequeueSuccessful();				
						just_add=false;
					}
					else
					{
						System.out.println("Local buffered!!");
						//break;
						this.waiting.queuee(handle);
						wait=true;
						just_add=true;
						Main.tq1.dequeueSuccessful();
					}
					}catch(ArrayIndexOutOfBoundsException f){System.out.println("Cannot dequeue the main queue!!");}
				
			pWriter.close();
			System.out.println(this.waiting.getEnd());

			}
		}
	}


}
