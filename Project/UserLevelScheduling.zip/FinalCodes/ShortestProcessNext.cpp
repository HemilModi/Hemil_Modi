#include<iostream>
#include<cstdio>

using namespace std;

class Thread 
{
	public:
		int arrivalTime;
		int remainingExecutionTime;
		int serviceTime;
};

void takeInput(void);
void sortingShortestProcess(void);
void insertInQueueMaybe(void); //Thread is calling, maybe?
void removeFromQueue(void);
void moveQueue(void);
int queue[5], tail=-1, clk=0;
Thread thr[5];

int main(void)
{
	int x1, x2;//
	freopen("input.txt","r",stdin);
	int i;
	takeInput();
	insertInQueueMaybe();
	
	do
	{
		clk++;
		thr[queue[0]-1].remainingExecutionTime--;
		cout<<"Clk: "<<clk;
		for(i=0; i<queue[0]; i++)
		{
			cout<<"\t";
		}
		cout<<queue[0]<<endl;
		
		insertInQueueMaybe();
		if(thr[queue[0]-1].remainingExecutionTime==0)
		{
			removeFromQueue();
		}
		
	}while(tail>=0);   //while(queueEmpty()==0);
	return 0;
}
/*void queueEmpty()
{
	if
}*/
void moveQueue()
{
	int temp, i;
	temp = queue[0];
	for(i=0; i<tail; i++)
	{
		queue[i] = queue[i+1];
	}
	queue[tail]=temp;
}

void removeFromQueue()
{
	int i;
	for(i=0; i<tail; i++)
	{
		queue[i] = queue[i+1];
	}
	tail = tail -1;
	sortingShortestProcess();
}
void takeInput(void)
{
	int temp;
	for(temp=0; temp<5; temp++)
	{
		//cout<<"Enter the arrival time of thread no. "<<temp+1<<"\t";
		cin>>thr[temp].arrivalTime;
		//cout<<"Enter the execution time of thread no. "<<temp+1<<"\t";
		cin>>thr[temp].serviceTime;
		thr[temp].remainingExecutionTime = thr[temp].serviceTime; 
	}
}

void insertInQueueMaybe(void)
{
	int temp1, temp2, temp3;
	for(temp1=0; temp1<5; temp1++)
	{
		if(clk==thr[temp1].arrivalTime)
		{
			queue[tail+1]=temp1+1;
			tail++;
		}
	}
}

void sortingShortestProcess(void)
{
	int i, j, temp;
	for(i=tail; i>0; i--)
	{
		for(j=i-1; j>=0; j--)
		{
			//cout<<"Inside sorting: "<<"Qi   "<<queue[i]<<"   Qj    "<<queue[j]<<endl;
			if(thr[queue[j]-1].serviceTime>thr[queue[i]-1].serviceTime)
			{
				temp=queue[j];
				queue[j]=queue[i];
				queue[i]=temp;
				
			}
		}
	}
}

/*This program will not work if the queue gets empty at some intermediate time.*/
