import java.util.Random;

class MyProducer implements Runnable{
	//final ThreadQueue queue;
	MyThreads pro;

	MyProducer(ThreadQueue tq1){
		//this.queue=tq1;
	}
	MyProducer(){}


	public void run(){
		//System.out.println("in Producer");
		int j=0;
		while(j<80){
			//System.out.println("in pro running");
			pro=new MyThreads();
			pro.makeNewThread((new Random()).nextInt(50),Main.buff,Main.tq1,"Producer");
			//pro.makeNewThread((new Random()).nextInt(50),Main.tq1,"Producer");
			j++;
		}

	/*for(int i=0;i<Main.tq1.getEnd();i++){
				System.out.println(Main.tq1.dequeue().getAmt());
			}		*/
	}

	public ThreadQueue getQBack(){
		return Main.tq1;
	}
	
}