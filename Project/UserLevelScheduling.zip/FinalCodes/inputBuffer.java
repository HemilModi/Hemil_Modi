//buffer ma bdha restictions and lag add krvanu che

import java.util.Date;
import java.lang.String;
import java.io.*;
import java.text.SimpleDateFormat;

class inputBuffer{
	private int buffer;
	private int size;
	private int point;
	private int flag_full;
	private int flag_empty;
	private File outFile;
	private FileWriter fWriter;
	public PrintWriter pWriter;
	public		Date date;
	/***************
	File outFile = new File ("inputBuffer.dat");
	FileWriter fWriter=null;
 	try{  

     fWriter= new FileWriter (outFile);
    	
		 
 	}catch(IOException e){System.out.println("Cannot open file!!");} 
 	PrintWriter pWriter = new PrintWriter (fWriter);



	**********/
	inputBuffer(int n){
		this.buffer=0;
		this.size=n;
		this.point = this.buffer;
		this.flag_empty=1;
		this.flag_full=0;

	}
	protected void finalize(){
		pWriter.close();
	}



	private boolean isEmpty(){
		if(this.flag_empty==1)
			return true;
		else
			return false;
	}
	private boolean isFull(){
		if(this.flag_full==1)
			return true;
		else return false;

	}
	private boolean checkFull(){
		if(this.buffer==size)
			return true;
		else return false;
	}
	private boolean checkEmpty(){
		if(this.buffer==0)
			return true;
		else return false;

	}
	private boolean set_FlagFull(int flag){
		if(this.flag_full!=flag){
			this.flag_full=flag;
			return true;
		}
		else return false;

	}
	private boolean set_FlagEmpty(int flag){
		if(this.flag_empty!=flag){
			this.flag_empty=flag;
			return true;
		}
		else return false;
	}

	private boolean addToBuffer(int num){
		if(isEmpty()){
			this.buffer=this.buffer+num;
			this.pWriter.println("adding to buffer: "+num+ " Status:"+this.buffer+" "+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(date));

			set_FlagEmpty(0);
		}
		else if(isFull()){

			return false;
		}
		else{
			this.buffer=this.buffer+num;
			this.pWriter.println("adding to buffer: "+num+ " Status:"+this.buffer+" "+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(date));
			if(checkFull()){
				set_FlagFull(1);
			}
			else if(checkEmpty()){
				set_FlagEmpty(1);
			}
		}
		return true;

	}


	private boolean subFromBuffer(int num){
		if(isFull()){
			this.buffer=this.buffer-num;
			this.pWriter.println("eating to buffer: "+num+ " Status:"+this.buffer+ " "+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(date));
			set_FlagFull(0);
		}
		else if(isEmpty()){

			return false;
		}
		else{
			this.buffer=this.buffer-num;
			this.pWriter.println("eating to buffer: "+num+ " Status:"+this.buffer+" "+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(date));
			if(checkFull()){
				set_FlagFull(1);
			}
			else if(checkEmpty()){
				set_FlagEmpty(1);
			}
		}
		return true;

	}

	//PUBLIC METHODS

	public synchronized boolean add(int num){

		return addToBuffer(num);
	}

	public synchronized boolean eat(int num){
		return subFromBuffer(num);
	}
	int i=1;
	public synchronized boolean Myrun(String name,int amt){
		date=new Date();
		/*System.out.println(i+" "+name);
		i++;*/
		this.pWriter=fopen();
		boolean dummy=false;
		if(name.equals("Producer")){
			dummy=add(amt);
		}
		else if(name.equals("Consumer")){
			dummy=eat(amt);
		}
		fclose();
		return dummy;

	}
	public void run(){
		System.out.println("hi input buffer");

	}

	public PrintWriter fopen(){
			this.outFile = new File ("inputBuffer.dat");
		try{  
     	this.fWriter= new FileWriter (outFile,true);  	
		 
 		}catch(IOException e){System.out.println("Cannot open file!!");} 
 		this.pWriter = new PrintWriter (fWriter);
 		return pWriter;
	}
	public void fclose(){
		this.finalize();
	}

	/*public static void main(String args[]){
		inputBuffer buff = new inputBuffer(500);
		buff.add(100);
		buff.eat(50);
		buff.add(230);

		buff.eat(60);
		buff.finalize();
	}*/

}