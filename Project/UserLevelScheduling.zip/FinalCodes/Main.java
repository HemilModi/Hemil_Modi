

class Main{
	
	public static ThreadQueue tq1 = new ThreadQueue(1000);
	public static inputBuffer buff = new inputBuffer(1000);
	public static void print(){
		for(int i=0;i<Main.tq1.getEnd();i++){
				System.out.println(Main.tq1.dequeue().getAmt());
			}			
	}
	public static void main(String args[]){
		Thread t1,t2,t3,t4;
		FCFS sch1=new FCFS();
		MyProducer p1=new MyProducer();
		MyConsumer c1=new MyConsumer();
		t1=new Thread(p1);
		t2=new Thread(c1);
		t3=new Thread(sch1);
		//t3.setDaemon(true);
		//t3.start();
		t1.start();
		t2.start();
		t3.start();
		
		
		//System.out.println("Hiii");
		//Main.tq1=p1.getQBack();
		//tq1.printQueue();
		/*or(int i=0;i<Main.tq1.getEnd();i++){
			System.out.println(Main.tq1.dequeue().getAmt());
		}*/
		 try{  

 		 t2.join();  
 		}catch(Exception e){System.out.println(e);} 
		//t1.join();
		//demo d1= new demo();
		//Main.print();
		//for(int i=0;i<100;i++);
		//FCFS.schedule();

 		
	}
}