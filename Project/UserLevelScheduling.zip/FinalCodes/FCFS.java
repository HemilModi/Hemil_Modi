import java.io.*;
import java.util.Date;

import java.text.SimpleDateFormat;

class FCFS implements Runnable{
		MyThreads handle=new MyThreads();
		Date date;
	public void run(){
		File outFile = new File ("FCFS.dat");
		FileWriter fWriter=null;
		PrintWriter pWriter=null;
 		
		boolean ret_type=false;
		int cnt=0;
		while(true){
			date=new Date();
			if(Main.tq1.getEnd()!=0){
				/*File opening*/
				try{  
		     	 fWriter= new FileWriter (outFile,true);			 
		 		}catch(IOException e){System.out.println("Cannot open file!!");} 
		 		pWriter = new PrintWriter (fWriter);
				

				/**/
				handle=Main.tq1.dequeue();
				pWriter.println(handle.getsName()+" "+ handle.getAmt()+" "+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSSSSSS").format(date));
				
				if(handle.MyThreadStart()){
				System.out.println("dequeue successfully");
				//File closing
				Main.tq1.dequeueSuccessful();
				pWriter.close();
			
				}
				else{
					System.out.println("error while adding/subtracting buffer!!");
					//break;
				}

			}
		}
	}
}