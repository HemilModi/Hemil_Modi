import java.lang.*;



class MyThreads extends Thread{
	
	private int amount;
	private Thread dummy;
	private boolean ack;
	private String sname;
	//private Runnable target;
	private inputBuffer inbuff;
	

	MyThreads(){
		this.amount=0;
		this.dummy=null;
		this.ack=false;
		this.inbuff=null;
		//this.name=null;
		//this.target=null;
	}

	/*private Runnable getRunnable(){
		return this.target;
	}*/

	private boolean generateThread(String n1){
			//this.target=t;
			this.sname=n1;
			this.dummy=new Thread();
			return true;
	}
			
	private boolean setAmount(int amt){
		this.amount=amt;
		return true;
	}

	private int getAmount(){
		return this.amount;
	}

	private long getDummyId(){
		return this.dummy.getId();
	}
	
	//public methods

	public void makeNewThread(int amt,inputBuffer b1,ThreadQueue q1,String n1){
			setAmount(amt);
			this.ack=generateThread(n1);
			q1.queuee(this);
			this.inbuff=b1;
			//this.name=n1;
			//return this;
	}
	/*
	public boolean makeNewThread(int amt,Runnable target,Scheduler1 sch1){
			setAmount(amt);
			this.ack=generateThread(target);
			sch1.addToArray(this);
			//this.MyThreadStart();
			return true;
	}*/
	public long getMyThreadId(){

		return this.getDummyId();
	}

	public synchronized boolean MyThreadStart(){
		//this.getRunnable().rund(this.amount);
		//System.out.println("starting MyThread");
		  return this.inbuff.Myrun(this.getsName(),this.getAmt());
		//return true;
		//this.dummy.start();
	}

	public void MyThreadSuspend(){
		this.dummy.suspend();
	}

	public void MyThreadResume(){
		this.dummy.resume();
	}
	public void MyThreadDelay(){
		try{
               this.dummy.sleep(1000);
           }catch(InterruptedException e){ System.out.println("delay interrupted");}		
	}
	public int getAmt(){
		return this.getAmount();
	}

	public String getsName(){
		return this.sname;
	}
	}

	

	//CHECK CHECK MAIN CHECK!!! :p

	/*public static void main(String args[]){
		MyThreads mah1 = new MyThreads();
		st1 var=new st1();
		st2 var2=new st2();
		Scheduler1 sch=new Scheduler1(20);
		mah1.makeNewThread(23,var,sch);
		mah1.makeNewThread(44,var2,sch);
		System.out.println(mah1.getMyThreadId());
		//mah1.MyThreadStart();
	}*/




/*
	public void run(){
		int i=0;
		while(i<100){
		System.out.println("st1!!");
		i++;
		}
	}
}

class st2 implements Runnable{
	public void run(){
		int i=0;
		while(i<200){
		System.out.println("st2+++++++!!");
		i++;
		}
	}	
}*/
