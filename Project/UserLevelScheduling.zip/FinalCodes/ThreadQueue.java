//aa queue ne hji dynamic bnava nu che


class ThreadQueue {
	
	private MyThreads[] queue = null;
	private int head;
	private int tail;

	ThreadQueue(int n){
		queue=new MyThreads[n];
		head=0;
		tail=0;
	}

	public synchronized void queuee(MyThreads m1){
		
		this.queue[this.tail]=m1;
		this.tail++;
	}
	public synchronized MyThreads dequeue(){
		MyThreads dummy= this.queue[head];
		for(int i=0;i<this.tail;i++){
			queue[i]=queue[i+1];
		}
		
		//queue[queue.length-1]=null;
		return dummy;
	}

	public synchronized void dequeueSuccessful(){
		this.tail=this.tail-1;
	}
	public int getEnd(){
		return this.tail;
	}

	public void printQueue(){
		for(int i=0;i<this.getEnd();i++){
			System.out.println(this.dequeue().getAmt());
		}		
	}
	/*public static void main(String args[]){
		ThreadQueue q1=new ThreadQueue(15);
		MyThreads m1 ;
		for(int i=0;i<10;i++){
			m1 = new MyThreads();
			m1.makeNewThread(i,null,q1);
			//q1.queuee(m1);

		}
		for(int i=0;i<q1.getEnd();i++){
			System.out.println(q1.dequeue().getAmt());
		}
	}*/
	
}