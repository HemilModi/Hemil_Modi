#include<iostream>
#include<cstdio>

using namespace std;

class Thread 
{
	public:
		int arrivalTime;
		int executionTimeRemaining;
};

void takeInput(void);
void insertInQueueMaybe(void); //Thread is calling, maybe?
void removeFromQueue(void);
void moveQueue(void);
int queue[5], tail=-1, clk=0;
Thread thr[5];

int main(void)
{
	freopen("input.txt","r",stdin);
	int i;
	takeInput();
	insertInQueueMaybe();
	
	do
	{
		clk++;
		thr[queue[0]-1].executionTimeRemaining--;
		cout<<"Clk: "<<clk;
		for(i=0; i<queue[0]; i++)
		{
			cout<<"\t";
		}
		cout<<queue[0]<<endl;
	
		insertInQueueMaybe();
		if(thr[queue[0]-1].executionTimeRemaining==0)
		{
			removeFromQueue();
		}
		else
		{
			moveQueue();
		}
	}while(tail>=0);   //while(queueEmpty()==0);
	return 0;
}

void moveQueue()
{
	int temp, i;
	temp = queue[0];
	for(i=0; i<tail; i++)
	{
		queue[i] = queue[i+1];
	}
	queue[tail]=temp;
}

void removeFromQueue()
{
	int i;
	for(i=0; i<tail; i++)
	{
		queue[i] = queue[i+1];
	}
	tail = tail -1;
}
void takeInput(void)
{
	int temp;
	
	for(temp=0; temp<5; temp++)
	{
		//cout<<"Enter the arrival time of thread no. "<<temp+1<<"\t";
		cin>>thr[temp].arrivalTime;
		//cout<<"Enter the execution time of thread no. "<<temp+1<<"\t";
		cin>>thr[temp].executionTimeRemaining; 
	}
}

void insertInQueueMaybe(void)
{
	int temp;
	for(temp=0; temp<5; temp++)
	{
		if(clk==thr[temp].arrivalTime)
		{
			queue[tail+1]=temp+1;
			tail++;
		}			
	}
}

/*This program will not work if the queue gets empty at some intermediate time.*/
