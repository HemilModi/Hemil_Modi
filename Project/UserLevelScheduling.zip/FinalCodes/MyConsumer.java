import java.util.Random;

class MyConsumer implements Runnable{
	//final ThreadQueue  queue;
	MyThreads con;

	MyConsumer(ThreadQueue tq1){
		//this.queue=tq1;
	}
	MyConsumer(){}
	public void run(){
		//System.out.println("in Consumer");
		int i=0;
		while(i<100){
			//System.out.println("in consumer running");
			con=new MyThreads();
			con.makeNewThread((new Random()).nextInt(50),Main.buff,Main.tq1,"Consumer");
//			con.makeNewThread((new Random()).nextInt(50),Main.tq1,"Consumer");

			i++;
		}
	}
}	